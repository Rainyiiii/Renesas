ra/arm/CMSIS-NN/Source/ConvolutionFunctions/arm_convolve_s4.o: \
  ..\ra\arm\CMSIS-NN\Source\ConvolutionFunctions\arm_convolve_s4.c \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnfunctions.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_math_types.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_types.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnsupportfunctions.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\Internal\arm_nn_compiler.h
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnfunctions.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_math_types.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_types.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnsupportfunctions.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\Internal\arm_nn_compiler.h:

ra/arm/CMSIS-NN/Source/FullyConnectedFunctions/arm_fully_connected_get_buffer_sizes_s16.o: \
  ..\ra\arm\CMSIS-NN\Source\FullyConnectedFunctions\arm_fully_connected_get_buffer_sizes_s16.c \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnfunctions.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_math_types.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_types.h
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnfunctions.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_math_types.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_types.h:

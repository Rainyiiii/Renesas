ra/arm/CMSIS-NN/Source/NNSupportFunctions/arm_nn_vec_mat_mul_result_acc_s16.o: \
  ..\ra\arm\CMSIS-NN\Source\NNSupportFunctions\arm_nn_vec_mat_mul_result_acc_s16.c \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnsupportfunctions.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\Internal\arm_nn_compiler.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_math_types.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_types.h
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nnsupportfunctions.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\Internal\arm_nn_compiler.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_math_types.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS-NN\Include\arm_nn_types.h:

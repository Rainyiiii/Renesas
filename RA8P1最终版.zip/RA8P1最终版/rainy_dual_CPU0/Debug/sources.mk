################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_UPPER_SRCS := 
O_SRCS := 
ELF_SRCS := 
LINKER_SCRIPT := 
SX_SRCS := 
JMP_UPPER_SRCS := 
P_UPPER_SRCS := 
X_SRCS := 
SRC_SRCS := 
X_UPPER_SRCS := 
JMP_SRCS := 
FSY_UPPER_SRCS := 
PP_UPPER_SRCS := 
OBJ_UPPER_SRCS := 
ASM_SRCS := 
SX_UPPER_SRCS := 
O_UPPER_SRCS := 
S_UPPER_SRCS := 
ELF_UPPER_SRCS := 
C_UPPER_SRCS := 
OBJ_SRCS := 
S_SRCS := 
PP_SRCS := 
SRC_UPPER_SRCS := 
FSY_SRCS := 
P_SRCS := 
C_SRCS := 
JMP_DEPS := 
FSY_DEPS := 
C_UPPER_DEPS := 
SECONDARY_SIZE := 
SRC_UPPER_DEPS := 
P_UPPER_DEPS := 
S_DEPS := 
PP_UPPER_DEPS := 
P_DEPS := 
FSY_UPPER_DEPS := 
C_DEPS := 
CREF := 
SRC_DEPS := 
OBJCOPY := 
JMP_UPPER_DEPS := 
PP_DEPS := 
SX_DEPS := 
ASM_UPPER_DEPS := 
OBJS := 
SX_UPPER_DEPS := 
ASM_DEPS := 
MAP := 
S_UPPER_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
ra/arm/CMSIS-NN/Source/ActivationFunctions \
ra/arm/CMSIS-NN/Source/BasicMathFunctions \
ra/arm/CMSIS-NN/Source/ConcatenationFunctions \
ra/arm/CMSIS-NN/Source/ConvolutionFunctions \
ra/arm/CMSIS-NN/Source/FullyConnectedFunctions \
ra/arm/CMSIS-NN/Source/LSTMFunctions \
ra/arm/CMSIS-NN/Source/NNSupportFunctions \
ra/arm/CMSIS-NN/Source/PadFunctions \
ra/arm/CMSIS-NN/Source/PoolingFunctions \
ra/arm/CMSIS-NN/Source/ReshapeFunctions \
ra/arm/CMSIS-NN/Source/SVDFunctions \
ra/arm/CMSIS-NN/Source/SoftmaxFunctions \
ra/arm/CMSIS-NN/Source/TransposeFunctions \
ra/arm/CMSIS_6 \
ra/fsp/src/bsp/cmsis/Device/RENESAS/Source \
ra/fsp/src/bsp/mcu/all \
ra/fsp/src/bsp/mcu/ra8p1 \
ra/fsp/src/r_ceu \
ra/fsp/src/r_dmac \
ra/fsp/src/r_gpt \
ra/fsp/src/r_ioport \
ra/fsp/src/r_ipc \
ra/fsp/src/r_sdhi \
ra/fsp/src/r_spi_b \
ra/fsp/src/rm_ethosu \
ra/npu/ethos-u-core-driver/src \
ra_gen \
src/ai_model \
src \
src/fatfs \


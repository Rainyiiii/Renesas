src/yolo_detector.o: ..\src\yolo_detector.c ..\src\yolo_detector.h \
  D:\RA\second\rainy_dual_CPU0\ra_gen\hal_data.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\bsp_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\fsp_common_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\fsp_version.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_gen\bsp_clock_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_family_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_device_pn_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_device_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_override.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\r_lpm_device_types.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_mcu_info.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_elc.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_feature.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_peripheral.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\r_adc_device_types.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_ofs_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\board_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_gen\vector_data.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_exceptions.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\renesas.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_compiler.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_clang.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\R7KA8P1KF_core0.h \
  D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS_6\CMSIS\Core\Include\core_cm85.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\system.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_common.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\inc\api\fsp_common_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_compiler_support.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_tfu.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_sdram.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_mmf.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_ipc.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_ospi_b.h \
  bsp_linker_info.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_register_protection.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_irq.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_io.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_group_irq.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_clocks.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_module_stop.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_security.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\inc\fsp_features.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\inc\..\..\fsp\src\bsp\mcu\all\bsp_compiler_support.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_delay.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_mcu_api.h \
  D:\RA\second\rainy_dual_CPU0\ra_gen\common_data.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\rm_ethosu_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\rm_ethosu.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\rm_ethosu_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra\npu\ethos-u-core-driver\include\ethosu_driver.h \
  D:\RA\second\rainy_dual_CPU0\ra\npu\ethos-u-core-driver\include\ethosu_types.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_ioport.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_ioport_api.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\r_ioport_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_pin_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_ipc.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\r_ipc_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_ipc_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_spi_b.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_spi_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_transfer_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_gpt.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_timer_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_capture_api.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_ceu.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_dmac.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_sdhi.h \
  D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\r_sdhi_cfg.h \
  D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_sdmmc_api.h \
  ..\src\ai_model\model.h ..\src\ai_model\sub_0001_tensors.h \
  ..\src\ai_model\ethosu_common.h ..\src\ai_model\sub_0003_tensors.h
..\src\yolo_detector.h:
D:\RA\second\rainy_dual_CPU0\ra_gen\hal_data.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\bsp_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\fsp_common_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\fsp_version.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_gen\bsp_clock_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_family_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_device_pn_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_device_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_override.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\r_lpm_device_types.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_mcu_info.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_elc.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_feature.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\bsp_peripheral.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra8p1\r_adc_device_types.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_mcu_ofs_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\board_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_gen\vector_data.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_exceptions.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\renesas.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_compiler.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_clang.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\R7KA8P1KF_core0.h:
D:\RA\second\rainy_dual_CPU0\ra\arm\CMSIS_6\CMSIS\Core\Include\core_cm85.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\system.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_common.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\inc\api\fsp_common_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_compiler_support.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_tfu.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_sdram.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_mmf.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_ipc.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_ospi_b.h:
bsp_linker_info.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_register_protection.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_irq.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_io.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_group_irq.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_clocks.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_module_stop.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_security.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\inc\fsp_features.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\inc\..\..\fsp\src\bsp\mcu\all\bsp_compiler_support.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_delay.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_mcu_api.h:
D:\RA\second\rainy_dual_CPU0\ra_gen\common_data.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\rm_ethosu_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\rm_ethosu.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\rm_ethosu_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra\npu\ethos-u-core-driver\include\ethosu_driver.h:
D:\RA\second\rainy_dual_CPU0\ra\npu\ethos-u-core-driver\include\ethosu_types.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_ioport.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_ioport_api.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\r_ioport_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\bsp\bsp_pin_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_ipc.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\r_ipc_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_ipc_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_spi_b.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_spi_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_transfer_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_gpt.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_timer_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_capture_api.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_ceu.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_dmac.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\instances\r_sdhi.h:
D:\RA\second\rainy_dual_CPU0\ra_cfg\fsp_cfg\r_sdhi_cfg.h:
D:\RA\second\rainy_dual_CPU0\ra\fsp\inc\api\r_sdmmc_api.h:
..\src\ai_model\model.h:
..\src\ai_model\sub_0001_tensors.h:
..\src\ai_model\ethosu_common.h:
..\src\ai_model\sub_0003_tensors.h:
